import React from "react";
import { twMerge } from "tailwind-merge";

function ToolboxItems({
  habbits,
  className,
  wrapperClass,
}: {
  habbits: {
    title: string;
    emoji: string;
  }[];
  className?: string;
  wrapperClass?: string;
}) {
  return (
    <div
      className={twMerge(
        "flex [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)",
        className
      )}
    >
      <div className={twMerge("flex flex-none py-0.5 gap-6", wrapperClass)}>
        {habbits.map((item) => (
          <div
            key={item.title}
            className="inline-flex gap-2 px-6 rounded-lg py-3 border-2 border-yellow-400"
          >
            <span className="font-medium">{item.title}</span>
            <span>{item.emoji}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ToolboxItems;
