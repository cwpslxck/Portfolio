import { Header } from "@/sections/Header";
import Image from "next/image";

function Photoshop() {
  return (
    <>
      <Header />
      <div className="lg:container">
        <div className="w-full">
          <Image alt="Image" src={""} loading="lazy" className="w-full" />
        </div>
      </div>
    </>
  );
}

export default Photoshop;
