import { ContactSection } from "@/sections/Contact";
import { Footer } from "@/sections/Footer";
import Goto from "@/sections/Goto";
import { Header } from "@/sections/Header";
import { ProjectsSection } from "@/sections/Projects";
import React from "react";

function Projects() {
  return (
    <div>
      <Header />
      <Goto />
    </div>
  );
}

export default Projects;
